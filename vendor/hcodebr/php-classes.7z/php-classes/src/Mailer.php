<?php

namespace Hcode;

use Rain\Tpl;
use PHPMailer;
use SMTP;

class Mailer {

    const SERVER_EMAIL = "emailparatesteseprojetos@gmail.com";
    const SERVER_PASSWORD = "clofuwgqdeawrfpo";
    const SERVER_NAME = "Oliver HCode Store";

    private $mail;

    public function __construct($toAddress, $toName, $subject, $tplName, $data = array()){
        $config = array(
            "tpl_dir"   =>  $_SERVER["DOCUMENT_ROOT"]."/views/email/",
            "cache_dir" =>  $_SERVER["DOCUMENT_ROOT"]."/views-cache/",
            "debug"     =>  false
        );

        Tpl::configure($config);
        $tpl = new Tpl;

        foreach ($data as $key => $value){
            $tpl->assign($key, $value);
        }

        $html = $tpl->draw($tplName, true);

        $this->mail = new PHPMailer();

        //Server settings
        $this->mail->SMTPDebug = 0;
        $this->mail->isSMTP();
        $this->mail->Host       = "smtp.gmail.com";
        $this->mail->Debugoutput = "html";
        $this->mail->SMTPAuth   = true;
        $this->mail->Username   = Mailer::SERVER_EMAIL;
        $this->mail->Password   = Mailer::SERVER_PASSWORD;
        $this->mail->SMTPSecure = "tls";
        $this->mail->Port       = 587; //465
        $this->mail->msgHTML($html);

        //Recipients
        $this->mail->setFrom(Mailer::SERVER_EMAIL, Mailer::SERVER_NAME);
        $this->mail->addAddress($toAddress, $toName);     //Add a recipient
        $this->mail->addReplyTo(Mailer::SERVER_EMAIL, Mailer::SERVER_NAME);

        $this->mail->isHTML(true);
        $this->mail->Subject = $subject;
    }

    public function send(){
        return $this->mail->send();
    }
}

?>