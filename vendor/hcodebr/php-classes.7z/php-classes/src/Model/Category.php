<?php

namespace Hcode\Model;

use Hcode\Model;
use Hcode\DB\Sql;

class Category extends Model{

    public static function listAll(){
        $sql = new Sql();

        return $sql->select("SELECT * FROM TB_CATEGORIES
                                ORDER BY IDCATEGORY ASC");
    }

    public function save(){
        $sql = new Sql();

        $result = $sql->select("CALL SP_CATEGORIES_SAVE (:idcategory, :descategory)", array(
            ":idcategory"   =>  $this   ->  getidcategory(),
            ":descategory"  =>  $this   ->  getdescategory()));

        $this->setData($result[0]);

        Category::updateFile();
    }

    public function get($idcategory){
        $sql = new Sql();

        $result = $sql->select("SELECT * FROM TB_CATEGORIES
                        WHERE IDCATEGORY = :idcategory", array(
                            ":idcategory"   =>  $idcategory));

        $this->setData($result[0]);
    }

    public function delete(){
        $sql = new Sql();

        $result = $sql->query("DELETE FROM TB_CATEGORIES
                        WHERE IDCATEGORY = :idcategory", array(
                            ":idcategory"   =>  $this   ->  getidcategory()));

        Category::updateFile();                            
    }

    public static function updateFile(){
        $categories = Category::listAll();

        $html = array();

        foreach ($categories as $row){
            $path = "http://www.hcodecommerce.com.br" . DIRECTORY_SEPARATOR . "categories" . DIRECTORY_SEPARATOR . $row["idcategory"];
            $line = '<li><a href="'.$path.'">'.$row["descategory"].'</a></li>';
            array_push($html, $line);
        }

        file_put_contents($_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . "views" . DIRECTORY_SEPARATOR . "categories-menu.html", implode('', $html));
    }

    public function getProducts($related = true){
        $sql = new Sql();

        if ($related){
            return $sql->select("SELECT * FROM TB_PRODUCTS
                            WHERE IDPRODUCT IN(
                                SELECT PROD.IDPRODUCT FROM TB_PRODUCTS AS PROD
                                    INNER JOIN TB_PRODUCTSCATEGORIES AS PRODCAT
                                        ON PROD.IDPRODUCT = PRODCAT.IDPRODUCT
                                            WHERE PRODCAT.IDCATEGORY = :idcategory)", array(
                                                "idcategory"    =>  $this   ->  getidcategory()));
        }else{
            return $sql->select("SELECT * FROM TB_PRODUCTS
                            WHERE IDPRODUCT NOT IN(
                                SELECT PROD.IDPRODUCT FROM TB_PRODUCTS AS PROD
                                    INNER JOIN TB_PRODUCTSCATEGORIES AS PRODCAT
                                        ON PROD.IDPRODUCT = PRODCAT.IDPRODUCT
                                            WHERE PRODCAT.IDCATEGORY = :idcategory)", array(
                                                "idcategory"    =>  $this   ->  getidcategory()));
        }
    }

    public function addProduct(Product $product){
        $sql = new Sql();

        $sql->query("INSERT INTO TB_PRODUCTSCATEGORIES (IDCATEGORY, IDPRODUCT)
                        VALUES (:idcategory, :idproduct)", array(
                            ":idcategory"   =>  $this       ->  getidcategory(),
                            ":idproduct"    =>  $product    ->  getidproduct()));
    }

    public function removeProduct(Product $product){
        $sql = new Sql();

        $sql->query("DELETE FROM TB_PRODUCTSCATEGORIES 
                        WHERE IDCATEGORY = :idcategory
                        AND IDPRODUCT = :idproduct", array(
                            ":idcategory"   =>  $this       ->  getidcategory(),
                            ":idproduct"    =>  $product    ->  getidproduct()));
    }

    public function getProductsPage($page = 1, $itemsPage = 3){
        $start = ($page - 1) * $itemsPage;
        
        $sql = new Sql();

        $result = $sql->select("SELECT SQL_CALC_FOUND_ROWS * FROM TB_PRODUCTS AS PROD
                        INNER JOIN TB_PRODUCTSCATEGORIES AS PRODCAT
                            ON PROD.IDPRODUCT = PRODCAT.IDPRODUCT
                        INNER JOIN TB_CATEGORIES AS CATE
                            ON CATE.IDCATEGORY = PRODCAT.IDCATEGORY
                                WHERE CATE.IDCATEGORY = :idcategory
                        LIMIT $start, $itemsPage", array(
                            ":idcategory"   =>  $this   ->  getidcategory()));
        
        $resultTotal = $sql->select("SELECT FOUND_ROWS() AS NRTOTAL");
        $resultTotal = $resultTotal[0]["NRTOTAL"];

        $pages = ceil($resultTotal / $itemsPage);

        return array(
            "data"  =>  Product::checkList($result),
            "total" =>  (int)$resultTotal,
            "pages" =>  $pages
        );
    }

}

?>