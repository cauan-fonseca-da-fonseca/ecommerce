<?php

namespace Hcode\Model;

use Hcode\Model;
use Hcode\DB\Sql;

class Address extends Model{

}

?>