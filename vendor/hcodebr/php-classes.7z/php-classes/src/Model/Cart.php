<?php

namespace Hcode\Model;

use Hcode\Model;
use Hcode\DB\Sql;

class Cart extends Model{

    const SESSION = "Cart";

    public static function getFromSession(){
        $cart = new Cart();

        if(isset($_SESSION[Cart::SESSION]) && (int)$_SESSION["Cart"]["idcart"] > 0){
            $cart->getSession((int)$_SESSION["Cart"]["idcart"]);
        }else{
            $cart->getSession();

            if(!(int)$cart->getidcart() > 0){
                $data = array(
                    "dessessionid"  =>  session_id());
                if(User::checkLogin(false)){
                    $user = User::getFromSession();
                    $data["iduser"] = $user->getiduser();
                }
                $cart->setData($data);

                $cart->save();
                $cart->setToSession();
            }
        }

        return $cart;
    }

    public function getSession(int $idcart = null){
        $sql = new Sql();

        if ($idcart){
            $result = $sql->select("SELECT * FROM TB_CARTS WHERE IDCART = :idcart", array(
                ":idcart"   =>  $idcart));
        }else{
            $result = $sql->select("SELECT * FROM TB_CARTS WHERE DESSESSIONID = :dessessionid", array(
                ":dessessionid" =>  session_id()));
        }
        
        if (count($result) > 0) {
            $result = $result[0];
            $this->setData($result);
        }
    }

    public function save(){
        $sql = new Sql();

        $results = $sql->select("CALL SP_CARTS_SAVE (:idcart, :dessessionid, :iduser, :deszipcode, :vlfreight, :nrdays)", array(
            ":idcart"       =>  $this   ->  getidcart(),
            ":dessessionid" =>  $this   ->  getdessessionid(),
            ":iduser"       =>  $this   ->  getiduser(),
            ":deszipcode"   =>  $this   ->  getdeszipcode(),
            ":vlfreight"    =>  $this   ->  getvlfreight(),
            ":nrdays"       =>  $this   ->  getnrdays()));

        $results = $results[0];
        $this->setData($results);
    }

    public function setToSession(){
        $_SESSION[Cart::SESSION] = $this->getValues();
    }


    public function addProduct(Product $product){
        $sql = new Sql();

        $sql->query("INSERT INTO TB_CARTSPRODUCTS (IDCART, IDPRODUCT) VALUES (:idcart, :idproduct)", array(
            ":idcart"       =>  $this       ->  getidcart(),
            ":idproduct"    =>  $product    ->  getidproduct()));

        $this->getCalculateTotal();
    }

    public function removeProduct(Product $product, $all = false){
        $sql = new Sql();

        if ($all){
            $sql->query("UPDATE TB_CARTSPRODUCTS SET dtremoved = NOW() WHERE idcart = :idcart AND idproduct = :idproduct AND dtremoved IS NULL", array(
                ":idcart"       =>  $this       ->  getidcart(),
                ":idproduct"    =>  $product    ->  getidproduct()));
        }else{
            $sql->query("UPDATE TB_CARTSPRODUCTS SET dtremoved = NOW() WHERE idcart = :idcart AND idproduct = :idproduct AND dtremoved IS NULL LIMIT 1", array(
                ":idcart"       =>  $this       ->  getidcart(),
                ":idproduct"    =>  $product    ->  getidproduct()));
        }

        $this->getCalculateTotal();
    }

    public function getProducts(){
        $sql = new Sql();

        return Product::checkList(
            $sql->select("SELECT PROD.idproduct, PROD.desproduct, PROD.vlprice, PROD.vlwidth, PROD.vlheight, PROD.vllength, PROD.vlweight, PROD.desurl, 
                COUNT(*) AS nrquantidade, SUM(PROD.vlprice) AS vltotal
                    FROM TB_CARTSPRODUCTS AS CARTS
                        INNER JOIN TB_PRODUCTS AS PROD
                    ON CARTS.IDPRODUCT = PROD.IDPRODUCT
                        WHERE CARTS.IDCART = :idcart
                    AND CARTS.DTREMOVED IS NULL
                        GROUP BY PROD.IDPRODUCT, PROD.DESPRODUCT, PROD.VLPRICE, PROD.VLWIDTH, PROD.VLHEIGHT, PROD.VLLENGTH, PROD.VLWEIGHT, PROD.DESURL
                    ORDER BY PROD.DESPRODUCT", array(
                        ":idcart"   =>  $this   ->  getidcart())));
    }

    public function getProductsTotals(){
        $sql = new Sql();

        $results = $sql->select("SELECT SUM(vlprice) AS vlprice, SUM(vlwidth) AS vlwidth, SUM(vlheight) AS vlheight, SUM(vllength) AS vllength, SUM(vlweight) AS vlweight, COUNT(*) as nrquantidade
                                    FROM tb_products AS prod
                                        INNER JOIN tb_cartsproducts AS cart
                                            ON prod.idproduct = cart.idproduct
                                        WHERE cart.idcart = :idcart
                                            AND dtremoved IS NULL", array(
                                                ":idcart"   =>  $this   ->  getidcart()));
        
        if(count($results) > 0){
            return $results[0];
        }else{
            return array();
        }
    }

    public function setFreight($zipcode){
        $zipcode = str_replace("-", "", $zipcode);

        $totals = $this->getProductsTotals();

        if($totals["nrquantidade"] > 0){
            if($totals["vlheight"] < 2) $totals["vlheight"] = 2;
            if($totals["vllength"] < 15) $totals["vllength"] = 15;

            $build_query = http_build_query(array(
                "nCdEmpresa"            =>  "",
                "sDsSenha"              =>  "",
                "nCdServico"            =>  "40010",
                "sCepOrigem"            =>  "09853120",
                "sCepDestino"           =>  $zipcode,
                "nVlPeso"               =>  $totals["vlweight"],
                "nCdFormato"            =>  "1",
                "nVlComprimento"        =>  $totals["vllength"],
                "nVlAltura"             =>  $totals["vlheight"],
                "nVlLargura"            =>  $totals["vlwidth"],
                "nVlDiametro"           =>  "0",
                "sCdMaoPropria"         =>  "N",
                "nVlValorDeclarado"     =>  $totals["vlprice"],
                "sCdAvisoRecebimento"   =>  "S"
            ));

            $xml = simplexml_load_file("http://ws.correios.com.br/calculador/CalcPrecoPrazo.asmx/CalcPrecoPrazo?" . $build_query);
            $webService = $xml->Servicos->cServico;

            if($webService->MsgErro != ""){
                Error::setMsgError($webService->MsgErro);
            }else{
                Error::clearMsgError();
            }

            $vlfreight = Cart::formatValueToDecimal($webService->Valor);

            $this-> setnrdays($webService->PrazoEntrega);
            $this-> setvlfreight($vlfreight);
            $this-> setdeszipcode($zipcode);

            $this->save();

            return $webService;
        }
    }

    public static function formatValueToDecimal($value):float{
        $value = str_replace(".", "", $value);
        $value = str_replace(",", ".", $value);
        return $value;
    }

    public function updateFreight(){
        if($this->getdeszipcode() != ""){
            $this->setFreight($this->getdeszipcode());
        }
    }

    public function getValues(){
        $this->getCalculateTotal();

        return parent::getValues();
    }

    public function getCalculateTotal(){
        $this->updateFreight();
        
        $totals = $this->getProductsTotals();

        $this->setvlsubtotal($totals["vlprice"]);
        $this->setvltotal($totals["vlprice"] + $this->getvlfreight());
    }
    
}

?>