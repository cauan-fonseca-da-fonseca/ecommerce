<?php

namespace Hcode\Model;

use Hcode\Model;
use Hcode\Page;

class Error extends Model{


    const SESSION_ERROR = "Error";
    const SESSION_ERROR_LOGIN = "LoginError";

    public static function setMsgError($mesage){
        $_SESSION[Error::SESSION_ERROR] = $mesage;
    }

    public static function getMsgError(){
        $mesage = false;
        if(isset($_SESSION[Error::SESSION_ERROR])){
            $mesage = $_SESSION[Error::SESSION_ERROR];
        }
        Error::clearMsgError();
        return $mesage;
    }

    public static function clearMsgError(){
        $_SESSION[Error::SESSION_ERROR] = null;
    }

    public static function setLoginError($mesage){
        $_SESSION[Error::SESSION_ERROR_LOGIN] = $mesage;
    }

    public static function getLoginError(){
        $mesage = false;
        if(isset($_SESSION[Error::SESSION_ERROR_LOGIN])){
            $mesage = $_SESSION[Error::SESSION_ERROR_LOGIN];
        }
        Error::clearMsgError();
        return $mesage;
    }

    public static function clearLoginError(){
        $_SESSION[Error::SESSION_ERROR_LOGIN] = null;
    }

    public static function checCreateLogin($data = array()){
        $check = User::checkLoginExist($_POST["email"]);
        if($check){
            Error::setLoginError("Não foi possível cadastrar o usuário. Por favor, tente com outro endereço de e-mail!");
            header("Location: /login");
            exit;
        }

        foreach($data as $key => $value){
            if (!isset($data[$key]) || $data[$key] == ""){
                switch($key){
                    case "name":
                        $key = "Nome";
                        break;
                    case "email":
                        $key = "E-mail";
                        break;
                    case "phone":
                        $key = "Telefone";
                        break;
                    case "password":
                        $key = "Senha";
                        break;
                    default:
                        throw new \Exception("Erro incomum ocorrido!");
                        break;
                }
                Error::setLoginError("Preencha o campo $key corretamente!");
                header("Location: /login");
                exit;
            }
        }

    }

}

?>